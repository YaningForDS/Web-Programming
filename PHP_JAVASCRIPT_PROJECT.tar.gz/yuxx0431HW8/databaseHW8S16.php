<?php
      $db_servername = 'egon.cs.umn.edu';
      $db_port = 3307;
      $db_name = 'S16CS4131U123';
      $db_username = 'S16CS4131U123';
      $db_password = 18462;
?>
