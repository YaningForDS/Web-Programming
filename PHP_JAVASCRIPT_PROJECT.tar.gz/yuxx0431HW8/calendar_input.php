
<?php
session_start();

$con = mysqli_connect('egon.cs.umn.edu', 'S16CS4131U123', '18462','S16CS4131U123','3307');
$user_check = $_SESSION['username'];
$myquery = "SELECT acc_name FROM tbl_accounts WHERE acc_name = '$user_check'";
$run=$con -> query($myquery);
$row = $run -> fetch_assoc();
$login_session = $row['acc_name'];
if (!isset($_SESSION['username'])){
	header("location:login.php");
}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset = "utf-8">
		<title>Calendar Input </title>
		<link rel="stylesheet" type="text/css" href="AdRotator.css" />
		<script src = "AdRotator.js">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
		</script>
		
	</head>
	<body onload = "startSlideShow()">
		
		<div class= "subtitle">
		<p><?php echo "Welcome ".$_SESSION['logname'];?></p>
		<p><a href="http://www-users.cselabs.umn.edu/~yuxx0431/yuxx0431HW8/logout.php">Logout</a></p>  
		<h1 class="title">Calender Input</h1>
		</div>
		<div>
		   <!-- Page Buttons: selection -->
		<img src = "prev_blue.png" onclick="renderImage(0)"  alt = "a" id="back"/>
		<a id = "mylink"><img id="image_display" onclick = "linkon()" src = 'oscar.jpg' class = "imageshow" alt = "b"/></a>
		<img src = "next_blue.png" onclick="renderImage(1)" alt = "c" id="next"/><br><br> 
		<img src = "bullet_gray.png" onclick = "bulletimage(0)" alt = "d" id = "first"/>
		<img src = "bullet_gray.png" onclick = "bulletimage(1)" alt = "e" id = "second"/>
		<img src = "bullet_gray.png" onclick = "bulletimage(2)" alt = "f" id = "third"/>

		</div>
	
		<div class="write">
		<hr>
		<nav><h3><a href="yuxx0431calendar.php">Calendar</a>   <a href="calendar_input.php">Input</a></h3></nav>
		<hr/>
		</div>
		

		<div class = "write">
		<form method="GET" action="calendar_input.html">
			<label class = "tp">Event Name:
				<input class = "widthsize" type="text" name="Event Name" value="" required/><br/>
			</label>
			<label class = "tp">Start Time:
				<input class = "widthsize" type="time" name="Start Time" value="" required/><br/>
			</label>
			<label class = "tp">End Time:
				<input class = "widthsize" type="time"	name="End Time" value="" required/><br/>
			</label>
			<label class = "tp">Location:
				<input class = "widthsize" type = "text" name="Location" value="" required /><br/>
			</label>
			
			<input class = "widthsize" type = "submit" value = "Submit" />
		</form>
		</div>
		<p class = "write">＊This page has been tested in Google Chrome</p>
	</body>
</html>



