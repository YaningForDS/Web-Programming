
Directory:

http://www-users.cselabs.umn.edu/~yuxx0431/yuxx0431HW8


For login:

http://www-users.cselabs.umn.edu/~yuxx0431/yuxx0431HW8/login.php

for calendar:

http://www-users.cselabs.umn.edu/~yuxx0431/yuxx0431HW8/yuxx0431calendar.php

for addrotator:
http://www-users.cselabs.umn.edu/~yuxx0431/yuxx0431HW8/calendar_input.php
