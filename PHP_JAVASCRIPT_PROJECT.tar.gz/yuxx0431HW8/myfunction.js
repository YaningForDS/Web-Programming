


var mylist = new Array("v1.jpg", "k.jpg","b.jpg","west.jpg");

var $ = function(id){
	return(document.getElementById(id));
}
function closepic(myloc){
	var div_i = document.getElementById(myloc);
	var closeone;
	div_i.innerHTML = "<button type = button onclick = openpic('" + myloc + "')>picture</button>";
}
function openpic(myloc){
	var div_i = document.getElementById(myloc);
	var pic;
	var pictname;

	for (i = 1; i < 5; i++){
		closepic('pic' + i);
	}
	if (myloc == "pic1"){
		pic = mylist[0];
		pictname = "Vincent Hall"
	}
	else if (myloc == "pic2"){
		pic = mylist[1];
			pictname = "Keller Hall";

	}
	else if (myloc == "pic3"){
		pic = mylist[2];
			pictname = "Bruininks Hall";

	}
	else if (myloc == "pic4"){
		pic = mylist[3];
			pictname = "Bruininks Hall";

	}

	div_i.innerHTML = "<button type = button onclick = closepic('"+myloc+"')>picture</button>" + 
	"<div id = '"+myloc+" ' " + "class = back onclick = closepic('"+myloc+"')>" + 
	"<img src = "+ pic +" class = image onclick = closepic('"+myloc+"')></div>"	
}