<?php
session_start();

$con = mysqli_connect('egon.cs.umn.edu', 'S16CS4131U123', '18462','S16CS4131U123','3307');
$user_check = $_SESSION['username'];
$myquery = "SELECT acc_name FROM tbl_accounts WHERE acc_name = '$user_check'";
$run=$con -> query($myquery);
$row = $run -> fetch_assoc();
$login_session = $row['acc_name'];
if (!isset($_SESSION['username'])){
	header("location:login.php");
}
?>
<!DOCTYPE html>
<!-- Name:Yaning Yu    ID:5088595 -->
<html>
	<head>
		<meta charset = "utf-8">
		<meta name="viewport" content="initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="AdRotator.css" />

		<title>My Calendar</title>
		<script src="myfunction.js"></script>
		
	</head>
	<body>
	  <p><?php echo "Welcome ".$_SESSION['logname'];?></p>
	  <p><a href="http://www-users.cselabs.umn.edu/~yuxx0431/yuxx0431HW8/logout.php">Logout</a></p>  
		<div class="write">
		<h1 class="title">My Calendar</h1>
		</div>
		<div class="write">
		<hr>
		<nav><h3><a href="yuxx0431calendar.html">Calendar</a>   <a href="calendar_input.php">Input</a></h3></nav>
		<hr/>
		</div>
		<table class = "write">
			<tr><td><span class = "tip">Monday</span></td>
				
				<td><p>STAT 4893W</p><p class = "time">10:10am - 11:00am</p><p>Vincent Hall 1</P>
					<p id = "pic1">
					<button type = "button" onclick = "openpic('pic1')">picture</button></p></td>

				<td><p>CSCI 4131</p><p class = "time">11:15am - 12:30pm</p><p>Anderson Hall 350</P>
					<p id = "pic4">
					<button type = 'button' onclick = "openpic('pic4')">picture</button></p></td>
				<td><p>BIOL 1010</p><p class = "time">2:30pm - 3:20pm</p><p>Bruininks Hall 312</p>
					<p id = "pic3">
					<button type = 'button' onclick = "openpic('pic3')">picture</button></p></td>
			</tr>
			<tr><td ><span class = "tip">Tuesday</span></td>
				<td><p><a href="http://www.spatial.cs.umn.edu/Courses/Spring16/4707/index.php"> CSCI 4707</a></p><p class = "time">2:30pm - 3:45pm</p><p>Keller Hall 3-210</p>
					<p id = "pic2">
					<button type = 'button' onclick = "openpic('pic2')">picture</button></p></td>
			</tr>
			<tr><td ><span class = "tip">Wednesday</span></td>
				<td><p>STAT 4893W</p><p class = "time">10:10am - 11:00am</p><p>Vincent Hall 1</p>
				<p id = "pic">
				<button type = 'button' onclick = "openpic('pic1')">picture</button></p></td>
				
				<td><p>CSCI 4131</p><p class = "time">11:15am - 12:30pm</p><p>Anderson Hall 350</p>
					<p id = "pic8">
					<button type = 'button' onclick = "openpic('pic4')">picture</button></p></td>
				<td><p>BIOL 1010</p><p class = "time">2:30pm - 3:20pm</p><p>Bruininks Hall 312</p>
					<p id = "pic9">
					<button type = 'button' onclick = "openpic('pic3')">picture</button></p></td>
			</tr>
			<tr><td ><span class = "tip">Thursday</span></td>
				
				<td><a href="http://www.spatial.cs.umn.edu/Courses/Spring16/4707/index.php"> CSCI 4707</a><p class = "time">2:30pm - 3:45pm</p><p>Keller Hall 3-210</p>
					<p id = "pic10">
					<button type = 'button' onclick = "openpic('pic2')">picture</button></p></td>
					
				
			</tr>
			<tr><td ><span class = "tip">Friday</span></td>
			
				<td><p>STAT 4893W</p><p class = "time">10:10am - 11:00am</p><p>Vincent Hall 1</p>
				<p id = "pic5">
				<button type = "button" onclick = "openpic('pic1')">picture</button></p></td>
				<td><p>CSCI 4131</p><p class = "time">11:15am - 12:30pm</p><p>Anderson Hall 350</p>
					<p id = "pic6">
					<button type = 'button' onclick = "openpic('pic4')">picture</button></p></td>
					
				<td><p>BIOL 1010</p><p class = "time">2:30pm - 3:20pm</p><p>Bruininks Hall 312</p>
					<p id = "pic7">
					<button type = 'button' onclick = "openpic('pic3')">picture</button></p></td>

			</tr>
			
		</table>
		<p class = "write">＊This page has been tested in Google Chrome</p>
		<p class = "write">Pictures are taken from the following links: </p>
		<p class = "write">http://campusmaps.umn.edu/sites/campusmaps.umn.edu/files/styles/building_photos/public/anderson_hall_050722_7991.jpg?itok=BqCHiFMY</p>
		<p class = "write">https://campusmaps.umn.edu/sites/campusmaps.umn.edu/files/styles/building_photos/public/bruininks_100802_9044_v3.jpg?itok=paKWRIMC</p>
		<p class = "write">http://www.math.umn.edu/finmath/poster/Old/vincent_hall-rd.jpg</p>
		<p class = "write">http://discover.umn.edu/sites/default/files/umnews/ur_multimedia_201299.jpg</p>
