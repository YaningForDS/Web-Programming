
<?php
session_start();
ini_set('display_errors','1');
error_reporting(E_ALL);
include_once 'databaseHW8S16.php';
$con = mysqli_connect('egon.cs.umn.edu', 'S16CS4131U123', '18462','S16CS4131U123','3307')
    or die('Cannot connect: ' . mysql_error());
   
    
$error = '';
   if(isset($_POST['submit'])){
      $username = $_POST['loginname'];
      $depass = $_POST['password'];
      $pass = sha1($depass);
      
           
      if($username=='' && $depass == '') {
		  $error .= 'Please enter a valid value for User Login and Password field.<br />';
		  $_SESSION['error'] = $error;
          //echo 'Please enter valid values for both Login Name and Password field. </br>';  
          //echo "<br>";         
      }
      else if ($username == '' && $depass != ''){
		  $error .= 'Please enter a valid value for User Login field.<br />';
		   $_SESSION['error'] = $error;
		  //echo 'Please enter a valid value for Login Name field';
		  //echo "<br>";
	  }
	  else if ($username != '' && $depass == ''){
		  $error .= 'Please enter a valid value for Password field.<br />';
		  $_SESSION['error'] = $error;
		  //echo 'Please enter a valid value for Password field';
		  //echo "<br>";
		  
	  }
      	
      else {
       $select_user = "SELECT * FROM tbl_accounts WHERE acc_login='$username'";
       $select_pass = "SELECT * FROM tbl_accounts WHERE acc_password='$pass'";
       $check_user = "SELECT * FROM tbl_accounts WHERE acc_login='$username'AND acc_password='$pass'";   
       
       $run=mysqli_query($con,$check_user); 
       $run_username=mysqli_query($con,$select_user);
       $run_pass=mysqli_query($con,$select_pass);
       
       //$userrows = mysqli_fetch_array($run_username);
       //$countuser = mysqli_num_rows($userrows);
       
       if(mysqli_num_rows($run) == 1){
		   $_SESSION['username'] = $username;
		   $result = $con->query($check_user);
		   $row = $result->fetch_assoc();
		   $_SESSION['logname'] = $row['acc_name'];
		   header("Location: yuxx0431calendar.php");
	   }
	   else if (mysqli_num_rows($run_username) >= 1){
		   $_SESSION['error'] = 'Password is incorrect. Please check the password and try again.<br />';
		   //echo 'Password is incorrect. Please check the password and try again';
		   
	   }
	   else if (mysqli_num_rows($run_username) == 0){
		   $_SESSION['error'] = 'Login is incorrect. Please check the login and try again.<br />';
		   //echo 'Login is incorrect. Please check the password and try again';
		
		 }
        
       }
       
	  }    
   
?> 


<?php 

    $err = "";
	if(isset($_SESSION['error']) && !empty($_SESSION['error'])) {
	$err = $_SESSION['error'];
	
}

?>
<html>
   <head>
      <meta charset = "utf-8">
      <link rel = "stylesheet" type = "text/css" href="AdRotator.css">
      <title>My Calendar</title>
   </head>   
	   
	   

<body>
     <div id="login" style="background-color:lightgrey; width:50%; left:50px;" >
      <h1>Login Page</h1>
      <div id="err" style="color:red;" ></div>
      <p>Please enter your user's name and password. Both values are case sensitive.</p>
      <form method = "post" action = "" >
          
          <label style="width:40px;">Login:</label>
          <input type="text" name="loginname" id="loginname"><br><br>
          <label style="width:40px;">Password:</label>
          <input type="password" name="password" id="password"><br>      
          
         <p><input type = "submit" name = "submit" value = "submit"  ></p>
      </form>
    
      
      <script>
			var information = <?php echo json_encode($err) ?>;
			document.getElementById("err").innerHTML = information;
			
		
				
		</script>
      </div>



  </body>
 </html>
