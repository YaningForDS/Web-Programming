var current_img = 0;
var previous_img = 0;
var num_img = 2; //There are 4, but the array indicies are 0-3
var myVar;  
var slideshown_on = false;
var current_slide = false;
var mydelay = 5000;


/* Arrays with the data information */
var imgList =new Array("oscar", "ice", "bowl");

var $ = function(id) {
	return(document.getElementById(id));
	}

function slideShow()
{
  var image_element = $("image_display");
  var old_image = 0;
  var image = imgList[current_img];
  image_element.src = image.concat(".jpg");
  if(current_img == 0){
       previous_img = num_img;
    }
  else{
       previous_img = current_img - 1;
    }

  old_image = imgList[previous_img];

  current_img = current_img + 1;
  if (current_img > num_img){current_img = 0;} // check for wrap-around

  clearTimeout(myVar);
  if (current_img == 0){
    myVar = setInterval(function(){slideShow()},3000);
  }
  else if(current_img == 1){
    myVar = setInterval(function(){slideShow()},5000);

  }
  else if (current_img == 2){
    myVar = setInterval(function(){slideShow()},7000);
  }
  //slideshown_on = true;
  //current_slide = true; 
  
}




function startSlideShow(){
  
  if(!slideshown_on){ 
    myVar = setInterval(function(){slideShow()}, mydelay);
 
   }
  else{ 
  alert("slide show is already active!");
  }
}

function bulletimage(my){
  var image_element = $("image_display");

  if (my == 0){
    image_element.src = imgList[0].concat(".jpg");


  }
  else if (my == 1){
    image_element.src = imgList[1].concat(".jpg");
   

  }
  else{
    image_element.src = imgList[2].concat(".jpg");
  }

}
/* Function that handles the following buttons: previous and next */
function renderImage(action)
{
  var image_element = $("image_display");
  var image;
  var old_image;
  
  switch (action)
  {
     case 0:  /* previous button */
       
       current_img = current_img - 1;
       if (current_img < 0){current_img = 2; previous_img = 0;}
       image = imgList[current_img];
       image_element.src = image.concat(".jpg");
       break;
     
        
     case 1:    /* Next Button */
       
     
        current_img = current_img + 1;
        if (current_img > num_img){current_img = 0; previous_img = 2;}
        image = imgList[current_img];
        image_element.src = image.concat(".jpg");
        break;
  }
}
function linkon(){
  var image_element = $("image_display");
  var image;
  image = imgList[current_img];
  if (image == "oscar"){
    $("mylink").href = "http://sua.umn.edu/events/calendar/event/14601/";

  }
  else if (image == "ice"){
    $("mylink").href = "http://sua.umn.edu/events/calendar/event/14617/";
  }
  else if (image == "bowl"){
    $("mylink").href ="http://sua.umn.edu/events/calendar/event/14616/";
  }

}










